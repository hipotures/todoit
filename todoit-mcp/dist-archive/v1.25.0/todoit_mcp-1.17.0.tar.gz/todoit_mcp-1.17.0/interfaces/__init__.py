"""
TODOIT MCP - Interfaces module
MCP Server and CLI interfaces
"""