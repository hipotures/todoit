"""
TODOIT MCP - Core module
Programmatic API for TODO list management
"""