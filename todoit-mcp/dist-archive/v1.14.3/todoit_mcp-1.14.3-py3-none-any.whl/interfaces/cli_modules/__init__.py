"""
CLI module for TODOIT
Modular CLI command structure
"""